"""For each exact pin in a notebook's install cell, ask PyPI which CPython versions have a
Linux x86_64 wheel (or a pure/abi3 wheel). usage: python pin_wheels.py <notebook> [<notebook> ...]"""
import json, re, sys, urllib.request
def pins_of(nb_path):
    nb = json.load(open(nb_path))
    for c in nb["cells"]:
        s = "".join(c["source"])
        if c["cell_type"] == "code" and "PINS = [" in s:
            block = s.split("PINS = [", 1)[1].split("]", 1)[0]
            return re.findall(r"'([A-Za-z0-9_.\-]+)==([^']+)'", block)
    return []
cache = {}
def wheels(name, ver):
    key = (name.lower(), ver)
    if key in cache: return cache[key]
    url = f"https://pypi.org/pypi/{name}/{ver}/json"
    try:
        data = json.load(urllib.request.urlopen(url, timeout=30))
    except Exception as exc:
        cache[key] = {"error": str(exc)}; return cache[key]
    tags = {"cp311": False, "cp312": False, "cp313": False}
    sdist = False
    for f in data["urls"]:
        fn = f["filename"]
        if fn.endswith(".tar.gz") or fn.endswith(".zip"): sdist = True; continue
        if not fn.endswith(".whl"): continue
        plat_ok = ("manylinux" in fn and "x86_64" in fn) or fn.endswith("-any.whl")
        if not plat_ok: continue
        if "py3-none" in fn or "py2.py3" in fn:
            for t in tags: tags[t] = True
        m = re.search(r"-cp3(\d+)-(cp3(\d+)t?|abi3|none)-", fn)
        if m:
            base = int(m.group(1))
            if m.group(2) == "abi3":
                for t in tags:
                    if int(t[3:]) >= base: tags[t] = True
            else:
                t = f"cp3{base}"
                if t in tags and not m.group(2).endswith("t"): tags[t] = True
    cache[key] = {"linux_x86_64_wheel": tags, "sdist": sdist, "requires_python": data["info"].get("requires_python")}
    return cache[key]
out = {}
for nb in sys.argv[1:]:
    out[nb] = {f"{n}=={v}": wheels(n, v) for n, v in pins_of(nb)}
print(json.dumps(out, indent=1))
