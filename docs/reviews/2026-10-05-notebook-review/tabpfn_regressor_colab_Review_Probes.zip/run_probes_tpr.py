"""TPR / TPRA probes: exec the TabPFN-3 regressor notebooks' own cells torch-free.

usage: python run_probes_tpr.py <repo checkout> <out dir>
"""
from __future__ import annotations
import io, json, os, pickle, shutil, sys, tempfile, types, zipfile
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
import harness as H

REPO = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]).resolve(); OUT.mkdir(parents=True, exist_ok=True)
E2E = REPO / "tutorials/tabpfn_regressor_colab.ipynb"
AI = REPO / "tutorials/tabpfn_regressor_artifact_inference_colab.ipynb"
RESULTS = {}

from sklearn.base import BaseEstimator
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
class StandInTabPFNRegressor(BaseEstimator):
    """scikit-learn stand-in with TabPFNRegressor's constructor/fit/predict surface (NOT the model)."""
    def __init__(self, model_path=None, device="cpu", n_estimators=4, random_state=42, show_progress_bar=False):
        self.model_path = model_path; self.device = device; self.n_estimators = n_estimators
        self.random_state = random_state; self.show_progress_bar = show_progress_bar
    def fit(self, X, y):
        Path(self.model_path).read_bytes()
        cats = [c for c in X.columns if not pd.api.types.is_numeric_dtype(X[c])]
        nums = [c for c in X.columns if c not in cats]
        pre = ColumnTransformer([("n", make_pipeline(SimpleImputer(), StandardScaler()), nums), ("c", OneHotEncoder(handle_unknown="ignore"), cats)])
        self._m = make_pipeline(pre, Ridge(1.0)).fit(X, np.asarray(y, dtype=float)); return self
    def predict(self, X):
        return self._m.predict(X)

def save_fitted(est, path):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("init_params.json", json.dumps(est.get_params(deep=False)))
        z.writestr("state.pkl", pickle.dumps(est))
        z.writestr("padding.bin", b"\0" * 2048)
def load_fitted(path, device="cpu"):
    with zipfile.ZipFile(path) as z:
        params = json.loads(z.read("init_params.json")); est = pickle.loads(z.read("state.pkl"))
    Path(params["model_path"]).read_bytes(); est.model_path = params["model_path"]; return est

tabpfn = types.ModuleType("tabpfn"); tabpfn.TabPFNRegressor = StandInTabPFNRegressor
ml = types.ModuleType("tabpfn.model_loading"); ml.save_fitted_tabpfn_model = save_fitted; ml.load_fitted_tabpfn_model = load_fitted
tabpfn.model_loading = ml; sys.modules["tabpfn"] = tabpfn; sys.modules["tabpfn.model_loading"] = ml
torch = H.install_stub_modules({"tabpfn": "8.1.0"}); torch.__version__ = "2.11.0+standin"
pickle_module_name = "__nbprobe__"

E2E_CELLS, e2e_nb = H.code_cells(E2E)
AI_CELLS, ai_nb = H.code_cells(AI)

def fresh_ns(workdir):
    os.chdir(workdir)
    mod = types.ModuleType("__nbprobe__"); sys.modules["__nbprobe__"] = mod; ns = mod.__dict__
    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
    steps = [H.run_cell(ns, E2E_CELLS[i], i) for i in [3, 5]]
    os.environ.pop("DIMER_NOTEBOOK_CI_PREINSTALLED")
    assert all(s["ok"] for s in steps), steps
    w = Path(workdir) / "weights" / ns["WEIGHTS_FILE"]; w.parent.mkdir(exist_ok=True); w.write_bytes(b"stand-in checkpoint " * 100)
    ns["WEIGHTS_SHA256"] = H.sha256(w)
    ns["pipe"] = ns["TabPFNRegressorPipeline"](weights_path=w, device="cpu")
    return ns

def set_form(src, name, value):
    lines = src.split("\n")
    for k, line in enumerate(lines):
        if line.startswith(f"{name} = "):
            comment = line[line.index("#"):] if "#" in line else ""
            lines[k] = f"{name} = {value!r}  {comment}"; return "\n".join(lines)
    raise KeyError(name)

E2E_STAGES = [9, 11, 13, 15, 17, 19, 21]
def run(cells, stages, workdir, forms=None, uploads=(), colab=True):
    c = H.Colab() if colab else None
    if c: c.queue.extend(uploads)
    ns = fresh_ns(workdir); steps = []
    for i in stages:
        src = cells[i]
        for (cell, name), value in (forms or {}).items():
            if cell == i: src = set_form(src, name, value)
        s = H.run_cell(ns, src, i); steps.append(s)
        if not s["ok"]: break
    if c: H.Colab.remove()
    last = steps[-1]
    return ns, {"cells_ok": [s["cell"] for s in steps if s["ok"]], "stopped_in_cell": None if last["ok"] else last["cell"], "error": last.get("error")}

# P1 default
wd = Path(tempfile.mkdtemp(prefix="tpr_p1_")); ns, r = run(E2E_CELLS, E2E_STAGES, wd)
if r["stopped_in_cell"] is None:
    r.update(splits={k: len(ns[k]) for k in ("train_df", "val_df", "test_df")}, feature_columns=ns["FEATURE_COLUMNS"],
             training_mean_baseline=ns["baseline"], target_near_zero_val=int((ns["val_df"]["target"].abs() < 0.1).sum()), target_min_abs_val=float(ns["val_df"]["target"].abs().min()), findings=ns["input_manifest"]["findings"], dataset_zip_sha256=ns["dataset_sha256"],
             reload_check=ns["reload_check"], outputs=sorted(os.listdir(wd / "outputs")),
             predictions_columns=list(pd.read_csv(wd / "outputs/tabpfn_regressor_predictions.csv").columns),
             stand_in_validation_metrics_not_model_evidence=ns["validation_metrics"])
RESULTS["P1_default_standin"] = r
E2E_WD, E2E_NS = wd, ns

# P2 baselines on the synthetic sample
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
tr, va, te = ns["train_df"], ns["val_df"], ns["test_df"]
Xd = lambda d: pd.get_dummies(d.drop(columns="target"), columns=["category"], dtype=float)
def m4(y, p):
    nz = y != 0
    return {"mae": round(float(mean_absolute_error(y, p)), 4), "rmse": round(float(np.sqrt(mean_squared_error(y, p))), 4), "r2": round(float(r2_score(y, p)), 4), "mape": round(float(np.mean(np.abs((y[nz] - p[nz]) / y[nz]))), 3)}
p2 = {"sample": "build_synthetic_dataset(rows=600, seed=42): target = 4*x1 - 1.5*x2 + category effect + N(0, 0.35) - 1", "irreducible_noise_sd": 0.35, "models": {}}
p2["models"]["training_mean"] = {"val": m4(va["target"].to_numpy(), np.full(len(va), tr["target"].mean()))}
for name, m in {"linear_regression(one-hot category)": LinearRegression(), "random_forest(300, seed 0)": RandomForestRegressor(300, random_state=0)}.items():
    m.fit(Xd(tr), tr["target"]); p2["models"][name] = {"val": m4(va["target"].to_numpy(), m.predict(Xd(va))), "test": m4(te["target"].to_numpy(), m.predict(Xd(te)))}
p2["val_targets_with_abs_below_0.1"] = int((va["target"].abs() < 0.1).sum())
RESULTS["P2_baselines"] = p2

# P3 BYOD matrix
base = pd.concat([tr, va, te]).reset_index(drop=True)
def zbytes(parts):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for n, df in parts.items(): z.writestr(n, df.to_csv(index=False) if isinstance(df, pd.DataFrame) else df)
    return b.getvalue()
p3 = {}
cases = {
  "zip_train_only_by_path": ({"train.csv": base}, "path"),
  "zip_train_val_test_by_upload": ({"train.csv": tr, "val.csv": va, "test.csv": te}, "upload"),
  "missing_target_values": ({"train.csv": base.assign(target=lambda d: d["target"].where(d.index % 50 != 0))}, "path"),
  "text_target_value": ({"train.csv": base.astype({"target": object}).assign(target=lambda d: d["target"].where(d.index != 0, "n.a."))}, "path"),
  "thousands_separator_targets": ({"train.csv": base.assign(target=lambda d: (d["target"] * 1000).map(lambda v: f"{v:,.1f}"))}, "path"),
  "constant_target": ({"train.csv": base.assign(target=1.0)}, "path"),
  "stray_string_in_numeric_feature": ({"train.csv": base.astype({"x1": object}).assign(x1=lambda d: d["x1"].where(d.index != 0, "abc"))}, "path"),
  "val_target_outside_train_range": ({"train.csv": tr, "val.csv": va.assign(target=lambda d: d["target"] * 5)}, "path"),
  "target_named_y": ({"train.csv": base.rename(columns={"target": "y"})}, "path"),
  "traversal_member": ({"../train.csv": base}, "path"),
}
for name, (parts, how) in cases.items():
    zp = Path(tempfile.mkdtemp()) / "mine.zip"; zp.write_bytes(zbytes(parts))
    forms = {(9, "USE_BYOD"): True}
    if how == "path": forms[(9, "BYOD_ZIP_PATH")] = str(zp); ups = []
    else: ups = [{"mine.zip": zp.read_bytes()}]
    nsb, rb = run(E2E_CELLS, E2E_STAGES, Path(tempfile.mkdtemp()), forms, ups)
    if "input_manifest" in nsb: rb["findings"] = [f.get("code") for f in nsb["input_manifest"]["findings"]]
    if "FEATURE_COLUMNS" in nsb and name == "stray_string_in_numeric_feature": rb["x1_dtype_in_train"] = str(nsb["train_df"]["x1"].dtype)
    p3[name] = rb
nsx, rx = run(E2E_CELLS, [9], Path(tempfile.mkdtemp()), {(9, "USE_BYOD"): True}, colab=False)
p3["byod_upload_outside_colab"] = rx
RESULTS["P3_byod_matrix"] = p3

# P4 new rows with identifier column; re-runs
p4 = {}
nr = te.drop(columns="target").head(5).assign(patient_ref=list("abcde")); nrp = E2E_WD / "new_with_id.csv"; nr.to_csv(nrp, index=False)
_, p4["new_rows_with_extra_identifier"] = run(E2E_CELLS, E2E_STAGES, Path(tempfile.mkdtemp()), {(19, "USE_BYOD_ROWS"): True, (19, "NEW_DATA_PATH"): str(nrp)})
again = [H.run_cell(E2E_NS, E2E_CELLS[i], i) for i in E2E_STAGES]
p4["rerun_sections_4_to_10_same_kernel"] = {"all_ok": all(s["ok"] for s in again), "errors": [s.get("error") for s in again if not s["ok"]]}
alone = H.run_cell(E2E_NS, E2E_CELLS[17], 17)
p4["rerun_export_cell_alone"] = {"ok": alone["ok"], "error": alone.get("error")}
RESULTS["P4_new_rows_and_reruns"] = p4

# P5 companion contract
ZIP = E2E_WD / "outputs/tabpfn_regressor_artifact.zip"
def ai(workdir, zip_path="", new_path="", zsha="", fsha="", csha="", uploads=(), colab=True):
    return run(AI_CELLS, [9, 11, 13, 15], workdir, {(9, "ARTIFACT_ZIP_PATH"): str(zip_path), (9, "EXPECTED_ZIP_SHA256"): zsha, (9, "EXPECTED_FITTED_SHA256"): fsha, (9, "EXPECTED_CKPT_SHA256"): csha, (13, "NEW_DATA_PATH"): str(new_path)}, uploads, colab)
p5 = {}
wd5 = Path(tempfile.mkdtemp(prefix="tpr_ai_"))
unl = wd5 / "new_rows.csv"; E2E_NS["new_rows"].to_csv(unl, index=False)
nsa, ra = ai(wd5, ZIP, unl, zsha=H.sha256(ZIP))
if ra["stopped_in_cell"] is None:
    pe = pd.read_csv(E2E_WD / "outputs/tabpfn_regressor_predictions.csv"); pa = pd.read_csv(wd5 / "outputs/tabpfn_regressor_artifact_inference_predictions.csv")
    ra["companion_equals_e2e"] = bool(np.allclose(pe["prediction"], pa["prediction"]))
    ra["outputs"] = sorted(os.listdir(wd5 / "outputs")); ra["evaluation_report_sample_kind"] = nsa["report"]["sample_kind"]
p5["e2e_zip_plus_new_rows_with_zip_sha"] = ra
p5["e2e_predictions_csv_as_new_input"] = ai(Path(tempfile.mkdtemp()), ZIP, E2E_WD / "outputs/tabpfn_regressor_predictions.csv")[1]
p5["zip_by_path_rows_by_upload"] = ai(Path(tempfile.mkdtemp()), ZIP, "", uploads=[{"new.csv": unl.read_bytes()}])[1]
p5["default_both_empty_outside_colab"] = ai(Path(tempfile.mkdtemp()), colab=False)[1]
p5["default_both_empty_colab_nothing_supplied"] = ai(Path(tempfile.mkdtemp()))[1]
p5["wrong_expected_zip_sha"] = ai(Path(tempfile.mkdtemp()), ZIP, unl, zsha="0" * 64)[1]
p5["wrong_expected_fitted_sha"] = ai(Path(tempfile.mkdtemp()), ZIP, unl, fsha="0" * 64)[1]
def rezip(fn, extra=None):
    d = Path(tempfile.mkdtemp()) / "b"; zipfile.ZipFile(ZIP).extractall(d); fn(d)
    out = Path(tempfile.mkdtemp()) / "b.zip"
    with zipfile.ZipFile(out, "w") as z:
        for p in sorted(d.iterdir()): z.write(p, p.name)
        for n, data in (extra or {}).items(): z.writestr(n, data)
    return out
def other_ckpt(d):
    c = d / "model.ckpt"; c.write_bytes(b"other weights " * 200)
    m = json.loads((d / "artifact_manifest.json").read_text()); m["foundationCheckpointSha256"] = H.sha256(c); (d / "artifact_manifest.json").write_text(json.dumps(m))
p5["other_checkpoint_rehashed"] = ai(Path(tempfile.mkdtemp()), rezip(other_ckpt), unl)[1]
def relabel(d):
    pass
p5["unlisted_extra_member"] = ai(Path(tempfile.mkdtemp()), rezip(lambda d: None, {"notes.txt": "hi"}), unl)[1]
p5["duplicate_basename_member_overwrites"] = ai(Path(tempfile.mkdtemp()), rezip(lambda d: None, {"sub/model.ckpt": b"x" * 4096}), unl)[1]
p5["traversal_member"] = ai(Path(tempfile.mkdtemp()), rezip(lambda d: None, {"../evil.txt": "x"}), unl)[1]
def tamper_fit(d):
    p = d / "model.tabpfn_fit"; p.write_bytes(p.read_bytes() + b"x")
p5["tampered_fitted_archive"] = ai(Path(tempfile.mkdtemp()), rezip(tamper_fit), unl)[1]
bad = E2E_NS["new_rows"].astype({"x1": object}); bad.loc[0, "x1"] = "abc"; bp = wd5 / "bad.csv"; bad.to_csv(bp, index=False)
nsbd, rbd = ai(Path(tempfile.mkdtemp()), ZIP, bp)
p5["non_numeric_value_in_numeric_feature"] = rbd
idp = wd5 / "with_id.csv"; E2E_NS["new_rows"].assign(patient_ref=range(len(E2E_NS["new_rows"]))).to_csv(idp, index=False)
p5["identifier_column"] = ai(Path(tempfile.mkdtemp()), ZIP, idp)[1]
RESULTS["P5_artifact_contract"] = p5

# P6 install guard: torch 2.11.0 requires cuda-bindings>=13.0.3 on Linux; Colab had 12.9.7 loaded
import importlib.metadata as md, subprocess as sp
real_run, real_ver, real_pd = sp.run, md.version, md.packages_distributions; state = {"installed": False}
sp.run = lambda *a, **k: state.update(installed=True)
md.packages_distributions = lambda: {**real_pd(), "cuda": ["cuda-bindings"]}
sys.modules.setdefault("cuda", types.ModuleType("cuda"))
md.version = lambda d: ("13.0.3" if state["installed"] else "12.9.7") if d == "cuda-bindings" else real_ver(d)
try:
    g = H.run_cell({"__name__": "__guard__"}, E2E_CELLS[3].split("\nimport torch, pandas")[0], 3)
finally:
    sp.run, md.version, md.packages_distributions = real_run, real_ver, real_pd
RESULTS["P6_install_guard_preloaded_cuda_bindings"] = {"simulated": "cuda-bindings loaded=12.9.7 (Colab T4, 2026-09-27 fleet record); torch==2.11.0 requires cuda-bindings>=13.0.3,<14 on Linux (PyPI metadata); pip replaced by a no-op", "ok": g["ok"], "error": g.get("error")}

p7 = {}
for label, (cells, nb) in (("e2e", (E2E_CELLS, e2e_nb)), ("companion", (AI_CELLS, ai_nb))):
    md_text = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    p7[label] = {"cells": len(nb["cells"]), "code_cells": len(cells), "declared": {k: nb["metadata"]["dimer"][k] for k in ("notebook_profile", "notebook_mode", "notebook_spec")},
                 "guided_markers": {k: (k.lower() in md_text.lower()) for k in ["How to use", "Roadmap", "Glossary", "What to notice", "Check your", "Troubleshoot", "Infrastructure", "Expected result"]},
                 "cellView_form_cells": sum(1 for c in nb["cells"] if c.get("metadata", {}).get("cellView") == "form"),
                 "restart_instruction_present": "Restart the runtime" in "".join(cells.values())}
RESULTS["P7_static"] = p7
text = json.dumps(RESULTS, indent=2, default=str).replace(tempfile.gettempdir(), "<tmp>")
(OUT / "results.json").write_text(text); print("written", OUT / "results.json")
