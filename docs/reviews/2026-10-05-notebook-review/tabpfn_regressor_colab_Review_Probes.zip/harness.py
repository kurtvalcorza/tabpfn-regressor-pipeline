"""Torch-free harness: exec a DIMER tabular notebook's own code cells with stand-ins.

Stand-ins: `google.colab.files.upload` (returns a prepared dict), a `torch` module stub (version
string and cuda.is_available() only), and an upstream estimator replaced by a scikit-learn model
that honours the same fit / predict_proba interface. The model itself is NOT exercised: numbers
produced through the stand-in are plumbing evidence only, never model evidence.
"""
from __future__ import annotations
import contextlib, hashlib, importlib, importlib.metadata, io, json, os, sys, tempfile, traceback, types
from pathlib import Path

_real_version = importlib.metadata.version


def code_cells(nb_path):
    nb = json.load(open(nb_path, encoding="utf-8"))
    return {i: "".join(c["source"]) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"}, nb


def install_stub_modules(fake_versions=None):
    fake_versions = dict(fake_versions or {})
    torch = types.ModuleType("torch")
    torch.__version__ = "stand-in"
    torch.float32 = "float32"
    torch.cuda = types.SimpleNamespace(is_available=lambda: False, get_device_name=lambda i=0: "none",
                                        manual_seed_all=lambda s: None, get_device_capability=lambda d=None: (0, 0))
    torch.manual_seed = lambda s: None
    def _no(*a, **k):
        raise RuntimeError("torch stand-in: tensor ops unavailable")
    torch.as_tensor = _no
    sys.modules["torch"] = torch

    def version(name):
        if name in fake_versions:
            return fake_versions[name]
        return _real_version(name)
    importlib.metadata.version = version
    return torch


class Colab:
    """google.colab stand-in; `queue` holds the dicts successive files.upload() calls return."""
    def __init__(self):
        self.queue = []
        self.calls = 0
        files = types.ModuleType("google.colab.files")
        def upload():
            self.calls += 1
            if not self.queue:
                raise RuntimeError("upload dialog opened with nothing queued (blocking in a real runtime)")
            return self.queue.pop(0)
        files.upload = upload
        colab = types.ModuleType("google.colab"); colab.files = files
        google = sys.modules.get("google") or types.ModuleType("google")
        google.colab = colab
        sys.modules["google"] = google; sys.modules["google.colab"] = colab; sys.modules["google.colab.files"] = files

    @staticmethod
    def remove():
        for k in ("google.colab", "google.colab.files"):
            sys.modules.pop(k, None)
        g = sys.modules.get("google")
        if g is not None and hasattr(g, "colab"):
            delattr(g, "colab")


def run_cell(ns, src, label):
    out = io.StringIO()
    try:
        with contextlib.redirect_stdout(out):
            exec(compile(src, f"<cell {label}>", "exec"), ns)
        return {"cell": label, "ok": True, "stdout_tail": out.getvalue()[-1500:]}
    except BaseException as exc:  # noqa: BLE001
        return {"cell": label, "ok": False, "error": f"{type(exc).__name__}: {exc}"[:800],
                "stdout_tail": out.getvalue()[-800:]}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
